#include "BSHNode.h"
#include "Mesh.h"

BSHNode::BSHNode(Mesh mesh){

}


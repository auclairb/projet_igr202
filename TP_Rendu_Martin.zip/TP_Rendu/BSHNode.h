#ifndef BSHNODE_H
#define BSHNODE_H
#include "Mesh.h"
#include "Vec3.h"
class BSHNode
{
 public:
  BSHNode(Mesh);
 private:
  Vec3f position;
  Vec3f normal;
  Vec3f color;
  float radius;
  BSHNode * leftChild;
  BSHNode * rightChild;
};

#endif
